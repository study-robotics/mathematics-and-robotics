import json

data = {}

total_data_num = 0

train_data_num = 1083
data["train"] = []
for i in range(total_data_num, total_data_num+train_data_num):
    data["train"].append(i)
total_data_num = total_data_num+train_data_num

val_data_num = 540
data["val"] = []
for i in range(total_data_num, total_data_num+val_data_num):
    data["val"].append(i)
total_data_num = total_data_num+val_data_num

test_data_num = 180
data["test"] = []
for i in range(total_data_num, total_data_num+test_data_num):
    data["test"].append(i)
total_data_num = total_data_num+test_data_num
list_data = []
list_data.append(data)
with open('./vox_cspace.json', 'w') as f:
    json.dump(list_data, f, indent=4, ensure_ascii=False)
