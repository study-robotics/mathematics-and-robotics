#!/usr/bin/env python
# -*- coding: utf-8 -*-
# license removed for brevity
import rospy
from std_msgs.msg import String
from moveit_msgs.msg  import DisplayRobotState, RobotState
from sensor_msgs.msg import JointState
from std_msgs.msg import Int32MultiArray
import numpy as np
import matplotlib.pyplot as plt
from skimage import io
import skimage


if __name__ == '__main__':
    all_not_collision_cspace = 0
    """
    for i in range(3400):
        collision_flag = False
        obstacleList = np.load("/workspace/Vox2Cspace/datasets/Cspaces/"+str(i)+".npy")
        for j in range(360):
            for k in range(360):
                if obstacleList[j][k] == 1:
                    collision_flag = True
        if collision_flag == False:
            all_not_collision_cspace += 1
            print("num", i)
            print("total", all_not_collision_cspace)
    
    """
    obstacleList = np.load("/workspace/Vox2Cspace/datasets/Cspaces/1003.npy")
    obstacles_img = (obstacleList)*255
    #このままだと、縦軸x,横軸yで原点が左下の図が表示されるので直す
    obstacles_img = np.rot90(obstacles_img, -1)#横軸x,縦軸y
    obstacles_img = np.fliplr(obstacles_img)#左右反転
    obstacles_img = skimage.img_as_ubyte(obstacles_img)
    obstacles_img = np.invert(obstacles_img)#そのままだと、障害物：白、背景：黒なので白黒を反転させる
    io.imshow(obstacles_img)
    print("end")
    plt.axis([0, 360, 0, 360])
    plt.grid(True)
    plt.show()
    
        
    #print(all_not_collsiion_cspace)
    
